#!/bin/bash

gcc main.c tmc5072.c -o main -l bcm2835
